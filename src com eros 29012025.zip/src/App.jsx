import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

// IMPORTAÇÃO IMPORTANTE: Pegamos o Provedor do arquivo .jsx
import { AuthProvider } from "./contexts/AuthProvider";
// Pegamos o Contexto do arquivo .js para usar no PrivateLayout
import { AuthContext } from "./contexts/AuthContext";

import "./App.css";

// Componentes e Páginas
import Menu from "./components/Menu";
import Login from "./pages/Login";
import Alunos from "./pages/Alunos";
import Cursos from "./pages/Cursos";
import Matriculas from "./pages/Matriculas";
import Agenda from "./pages/Agenda";
import FinanceiroGeral from "./pages/Financeiro";

// --- COMPONENTE DE PROTEÇÃO DE ROTA ---
const PrivateLayout = ({ children, roleRequired }) => {
  const { authenticated, user, loading } = React.useContext(AuthContext);

  if (loading) {
    return <div style={{ padding: "20px" }}>Carregando acesso...</div>;
  }

  if (!authenticated) {
    return <Navigate to="/login" />;
  }

  // Se o role for 'admin' (conforme seu banco)
  if (roleRequired && user?.role !== roleRequired) {
    return <Navigate to="/alunos" />;
  }

  return (
    <div style={{ display: "flex" }}>
      <Menu />
      <main style={{ flex: 1, padding: "20px", marginLeft: "40px" }}>
        {children}
      </main>
    </div>
  );
};

function AppContent() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Navigate to="/login" />} />

      {/* Rotas Comuns */}
      <Route path="/alunos" element={<PrivateLayout><Alunos /></PrivateLayout>} />
      <Route path="/cursos" element={<PrivateLayout><Cursos /></PrivateLayout>} />
      <Route path="/matriculas" element={<PrivateLayout><Matriculas /></PrivateLayout>} />
      <Route path="/agenda" element={<PrivateLayout><Agenda /></PrivateLayout>} />

      {/* Rota Administrativa */}
      <Route
        path="/financeiro"
        element={
          <PrivateLayout roleRequired="admin">
            <FinanceiroGeral />
          </PrivateLayout>
        }
      />

      <Route path="*" element={<Navigate to="/login" />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
      </Router>
    </AuthProvider>
  );
}