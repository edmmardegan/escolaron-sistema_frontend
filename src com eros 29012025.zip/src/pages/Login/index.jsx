import React, { useState, useContext } from 'react'; // useContext apenas uma vez!
import { AuthContext } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';
import "./styles.css";

export default function Login() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { login } = useContext(AuthContext);

  // O 'async' entra aqui antes do (e)
  async function handleSubmit(e) {
    e.preventDefault();

    try {
      // 1. Faz a chamada ao backend aqui na página de Login
      const response = await api.post("/auth/login", {
        email: username, // Se o seu backend espera 'email', passamos o username aqui
        senha: password,
      });

      // 2. Pega os dados que o NestJS enviou
      const { user, access_token } = response.data;

      // 3. Passa o objeto USER completo para o Contexto
      // Assim o Contexto guarda o 'role' e o 'nome'
      login(user, access_token);

      // 4. Navega para a página de alunos
      navigate("/alunos");
    } catch (err) {
      console.error(err);
      alert("Usuário ou senha incorretos!");
    }
  }

  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleSubmit}>
        <h2>BEM VINDO</h2>
        <h2>Acesso ao Sistema</h2>
        <input
          type="text"
          placeholder="Usuário"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          type="password"
          placeholder="Senha"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button type="submit">Entrar</button>
      </form>
    </div>
  );
}
