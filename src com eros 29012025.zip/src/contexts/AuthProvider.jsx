import React, { useState } from 'react';
import { AuthContext } from './AuthContext';

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const recovered = localStorage.getItem('user');
    return recovered ? JSON.parse(recovered) : null;
  });
  const login = (userData, token) => {
    localStorage.setItem('user', JSON.stringify(userData));
    localStorage.setItem('token', token);
    setUser(userData);
  };
  const logout = () => {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    setUser(null);
  };
  return (
    <AuthContext.Provider value={{ authenticated: !!user, user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}