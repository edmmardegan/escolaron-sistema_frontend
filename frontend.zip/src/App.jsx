import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import './App.css'; 

// Verifique se o caminho está exatamente onde você salvou o arquivo
import Menu from './components/Menu'; 

// Páginas
import Alunos from './pages/Alunos';
import Cursos from './pages/Cursos';
import Matriculas from './pages/Matriculas';
import Agenda from './pages/Agenda';
import FinanceiroGeral from './pages/Financeiro';


function App() {
  return (
    <Router>
      <div style={{ display: 'flex' }}>
        {/* O Menu PRECISA estar dentro do Router para o useLocation funcionar */}
        <Menu /> 

        <main style={{ flex: 1, padding: '20px', marginLeft: '240px' }}>
          <Routes>
            <Route path="/" element={<Navigate to="/alunos" />} />
            <Route path="/alunos" element={<Alunos />} />
            <Route path="/cursos" element={<Cursos />} />
            <Route path="/matriculas" element={<Matriculas />} />
            <Route path="/agenda" element={<Agenda />} />
            <Route path="/financeiro" element={<FinanceiroGeral />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;