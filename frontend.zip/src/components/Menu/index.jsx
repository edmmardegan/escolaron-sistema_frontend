import React from "react";
import { Link, useLocation } from "react-router-dom";
// Importamos apenas ícones básicos e GARANTIDOS
import {
  FaUser,
  FaBook,
  FaClipboardList,
  FaCalendarAlt,
  FaChartBar,
} from "react-icons/fa";
import "./styles.css";

export default function Menu() {
  const location = useLocation();

  // Função para verificar se o link está ativo
  const isActive = (path) => (location.pathname === path ? "active" : "");

  return (
    <nav className="sidebar">
      <div className="sidebar-header">
        <h3>Sistema Escolar</h3>
      </div>

      <ul className="nav-list">
        <li>
          <Link to="/alunos" className={isActive("/alunos")}>
            <FaUser /> Alunos
          </Link>
        </li>
        <li>
          <Link to="/cursos" className={isActive("/cursos")}>
            <FaBook /> Cursos
          </Link>
        </li>
        <li>
          <Link to="/matriculas" className={isActive("/matriculas")}>
            <FaClipboardList /> Matrículas
          </Link>
        </li>
        <li>
          <Link to="/financeiro" className={isActive("/financeiro")}>
            <FaChartBar /> Financeiro Geral
          </Link>
        </li>
        <li>
          <Link to="/agenda" className={isActive("/agenda")}>
            <FaCalendarAlt /> Agenda
          </Link>
        </li>
        <li>
          <Link to="/relatorios" className={isActive("/relatorios")}>
            <FaChartBar /> Relatórios
          </Link>
        </li>
      </ul>
    </nav>
  );
}
